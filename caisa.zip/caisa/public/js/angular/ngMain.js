var app = angular.module('App', ['ngMaterial', 'ngSanitize']);

app.config(['$interpolateProvider', function ($interpolateProvider) {
  $interpolateProvider.startSymbol('<%');
  $interpolateProvider.endSymbol('%>');
}]);

app.controller('Controller1', [
  "$scope",
  "$http",
  "$mdDialog",
  "$timeout",
  "$window",
  function ($scope, $http, $mdDialog, $timeout, $window) {

    $scope.a = "";
    $scope.b = "";
    $scope.fechaI = new Date();
    $scope.temporada = "";
    $scope.index = 0;
    $scope.totalPesoPasa = 0;
    $scope.cabPasArr = [{ "cabP": { "M": "", "F": "", "N": "", "A": 1, "P": "", "UI": "" } }];
    $scope.compArr = [{ "comp": { "max": "", "A": 1, "peso": "", "UI": "" } }];
    $scope.avionPesos = {
      id: "",
      marca: "",
      modelo: "",
      version: "",
      peso_operacional: "",
      carga_paga: "",
      peso_aterrizaje: "",
      peso_cero_combustible: "",
      peso_despegue_tow: "",
      peso_taxi: ""
    };
    $scope.avionesPesos;
    $scope.pesoHombre = 85;
    $scope.pesoMujer = 80;
    $scope.pesoNinio = 36;
    $scope.factorPeso = 1;
    $scope.unidadInidice = 0;
    $scope.data = {
      opcionesPesos: [
        {id: 1, name: 'KG'},
        {id: 2, name: 'LB'}
      ],
      pesoSeleccionado: {id:1, name: 'KG'}
      };
    $scope.factorPesoMax = 1;
    

    //se ejecuta al cargarse completamente la página
    angular.element(function () {
      var dateA = angular.element("#fechaesperada").val();
      if (dateA !== undefined)
        $scope.cambioFecha();
      $scope.getPesos();

    });

    /**
     * Valida la fecha que se ingresa y asigna un valor al campo temporada
     */
    $scope.cambioFecha = function () {
      var dateA = angular.element("#fechaesperada").val();
      var arrTmp = dateA.split("-");
      $scope.a = arrTmp[2] + "-" + arrTmp[1] + "-" + arrTmp[0];
      $scope.limiteA = "01-05-" + arrTmp[0];
      $scope.limiteB = "31-10-" + arrTmp[0];
      $scope.c = moment($scope.a, "DD-MM-YYYY");
      $scope.d = moment($scope.limiteA, "DD-MM-YYYY");
      $scope.e = moment($scope.limiteB, "DD-MM-YYYY");
      //console.log($scope.limiteA + "       " + $scope.limiteB + "    " + $scope.a);

      if ($scope.c.isSameOrAfter($scope.d) && $scope.c.isSameOrBefore($scope.e)) {
        //console.log($scope.c + ' es verano   ' + $scope.d + "    " + $scope.e);
        $scope.temporada = "VERANO";
        angular.element("#temporada").val("VERANO");
        $scope.pesoHombre = 85;
        $scope.pesoMujer = 80;
        $scope.pesoNinio = 36;
      } else {
        //console.log($scope.c + ' es invierno   ' + $scope.d + "    " + $scope.e);
        $scope.temporada = "INVIERNO";
        angular.element("#temporada").val("INVIERNO");
        $scope.pesoHombre = 88;
        $scope.pesoMujer = 78;
        $scope.pesoNinio = 34;
      }

    };

    /**
     * Agrega un conjunto de resgistros con todos los campos para la cabina de pasajeros
     */
    $scope.agregaCabPas = function () {

      var i = $scope.cabPasArr[$scope.cabPasArr.length - 1]["cabP"]["A"];
      var aux = { "cabP": { "M": "", "F": "", "N": "", "A": (++i), "P": "", "UI": "" } };
      $scope.cabPasArr.push(
        aux
      );
      //console.log(aux);
      //console.log($scope.cabPasArr);
    };

    /**
     * Elimina un conjunto de resgistros con todos los campos para la cabina de pasajeros
     */
    $scope.eliminaCabPas = function () {
      //console.log("la longitud es: " + $scope.cabPasArr.length);

      if ($scope.cabPasArr.length > 1) {
        var aux = $scope.cabPasArr.slice(
          0, $scope.cabPasArr.length - 1
        );

        $scope.cabPasArr.length = 0;
        $scope.cabPasArr = aux.slice(0);
        aux.length = 0;
      }

      for (var i = 0; i < 3; i++) {
        $scope.sumaPesoCol(i);
      }

      //console.log($scope.cabPasArr);
      //console.log(aux);
    };

    /**
     * Agrega un conjunto de resgistros con todos los campos para el compartimiento
     */
    $scope.agregaComp = function () {
      var i = $scope.compArr[$scope.compArr.length - 1]["comp"]["A"];
      var aux = { "comp": { "max": "", "A": (++i), "Peso": "", "UI": "" } };

      if ($scope.compArr.length < 5)
        $scope.compArr.push(
          aux
        );
      //console.log(aux);
      //console.log($scope.cabPasArr);
    };

    /**
     * Elimina un conjunto de resgistros con todos los campos para el compartimiento
     */
    $scope.eliminaComp = function () {
      //console.log("la longitud es: " + $scope.compArr.length);

      if ($scope.compArr.length > 1) {
        var aux = $scope.compArr.slice(
          0, $scope.compArr.length - 1
        );

        $scope.compArr.length = 0;
        $scope.compArr = aux.slice(0);
        aux.length = 0;
      }

      $scope.sumaPesoComp();

      //console.log($scope.compArr);
      //console.log(aux);
    };

    //método para obtener la unidad índice
    $scope.obtieneUnidadInidice = function (peso) {

      var sta = angular.element("#sta").val();
      var refSta = angular.element("#refsta").val();
      var constC = angular.element("#constC").val();
      var constK = angular.element("#constC").val();

      /* console.log("1.- sta: " + sta + "   refsta: " + refSta + "    constc: " + constC 
      + "    constk: " + constK + "    peso: " + peso); */

      if(sta===''){
        $scope.Modal(
          "Error",
          "El atributo sta está vacío."
        );
      }else if(refSta===''){
        $scope.Modal(
          "Error",
          "El atributo ref sta está vacío."
        );
      }else if(constC==='' || constC===0){
        $scope.Modal(
          "Error",
          "El atributo const C está vacío o es cero"
        );
      }else if(constK===''){
        $scope.Modal(
          "Error",
          "El atributo const K está vacío."
        );
      }else{
        //console.log("2.- sta: " + sta + "   refsta: " + refSta + "    constc: " + constC + "    constk: " + constK);
        $scope.unidadInidice = (peso * (sta - refSta) / constC) + constK;
        //(Peso * (sta -ref.sta)/(constante c)) + const. k = unidad indice
        return $scope.unidadInidice;
      }
    };

    /**
     * Función para actulizar unidades del peso y el cálculo
     */
    $scope.actualizaPesoEn = function(pesoEn){

      if(pesoEn["id"]===2){
        $scope.factorPeso = 2.2;
        $scope.factorPesoMax = 2.2;
      }else{
        $scope.factorPeso = 1;
        $scope.factorPesoMax = 1/2.2;
      }

      //console.log("factor peso: " + $scope.factorPeso);
      $scope.actualizaResultados();
      $scope.actualizaPesosMaximos();
    }

    $scope.actualizaResultados = function(){
      for(var i=0; i < $scope.cabPasArr.length; i++){
        $scope.sumaPesoFila(i);
      }

      $scope.sumaPesoCol();

      $scope.sumaPesoComp();

      $scope.recacularUnidadIndicePesos();

      /* $scope.Modal(
        "Exito",
        "Se actualizaron los resultados correctamente",
        "OK"
      ); */
    };

    /**
     * Suma el peso total de todas las columnas por fila
     */
    $scope.sumaPesoFila = function (fila) {

      var sum1 = angular.element("#AdultoMasculino" + (fila + 1)).val();

      var sum2 = angular.element("#AdultoFemenino" + (fila + 1)).val();

      var sum3 = angular.element("#Ninio" + (fila + 1)).val();

      if (sum1 === undefined || sum1 === null || sum1 === "" || sum1 === NaN || sum1 === 'NaN') {
        sum1 = 0;
      }
      if (sum2 === undefined || sum2 === null || sum2 === "" || sum2 === NaN || sum2 === 'NaN') {
        sum2 = 0;
      }
      if (sum3 === undefined || sum3 === null || sum3 === "" || sum3 === NaN || sum3 === 'NaN') {
        sum3 = 0;
      }

      var sumaTotal = (parseFloat(sum1) * parseFloat($scope.pesoHombre))
        + (parseFloat(sum2) * parseFloat($scope.pesoMujer)) + (parseFloat(sum3) * parseFloat($scope.pesoNinio));
        console.log("  sumatotal: " + sumaTotal + "   factorpeso: " + $scope.factorPeso);
      sumaTotal *= parseFloat($scope.factorPeso);
      console.log("  sumatotal: " + sumaTotal);

      angular.element("#Peso" + (fila + 1)).val(parseFloat(sumaTotal));

      var ui = $scope.obtieneUnidadInidice(sumaTotal);
      angular.element("#UnidadIn" + (fila + 1)).val(ui);

    };

    /**
     * Suma el peso total de todas los campos de una sola columna
     */
    $scope.sumaPesoCol = function () {
      //console.log("se suma el peso de esta columna");

      var sumHom = 0;
      var sumMuj = 0;
      var sumNin = 0;

      for (var i = 0; i < $scope.cabPasArr.length; i++) {
        var sum1 = angular.element("#AdultoMasculino" + (i + 1)).val();
        var sum2 = angular.element("#AdultoFemenino" + (i + 1)).val();
        var sum3 = angular.element("#Ninio" + (i + 1)).val();

        if (sum1 !== undefined && sum1 !== '') {
          console.log("sumHom: " + sumHom);
          sumHom = sumHom +  (parseFloat(sum1) * parseFloat($scope.pesoHombre) * parseFloat($scope.factorPeso));
          console.log("sum1: " + sum1 + "    pesoHombre: " + $scope.pesoHombre 
          + "     pesoFactor: " + $scope.factorPeso);
          console.log("sumHom: " + sumHom);
        } else {
          sum1 = 0;
          sumHom += 0;
          console.log("sumHom: " + sumHom);
        }
        if (sum2 !== undefined && sum2 !== '') {
          console.log("sumMuj: " + sumMuj);
          sumMuj = sumMuj + (parseFloat(sum2) * parseFloat($scope.pesoMujer) * parseFloat($scope.factorPeso));
          console.log("sum2: " + sum2 + "    pesoMuj: " + $scope.pesoMujer
          + "     pesoFactor: " + $scope.factorPeso);
          console.log("sumMuj: " + sumMuj);
        } else {
          sum2 = 0;
          sumMuj += 0;
          console.log("sumMuj: " + sumMuj);
        }
        if (sum3 !== undefined && sum3 !== '') {
          console.log("sumNin: " + sumNin);
          sumNin = sumNin + (parseFloat(sum3) * parseFloat($scope.pesoNinio) * parseFloat($scope.factorPeso));
          console.log("sum3: " + sum3 + "    pesoNin: " + $scope.pesoNinio
          + "     pesoFactor: " + $scope.factorPeso);
          console.log("sumNin: " + sumNin);
        } else {
          sum3 = 0;
          sumNin += 0;
          console.log("sumNin: " + sumNin);
        }

        var totaTotales = sumHom + sumMuj + sumNin;
        angular.element("#t1").val(sumHom);
        angular.element("#t2").val(sumMuj);
        angular.element("#t3").val(sumNin);

        angular.element("#total").val(totaTotales);
      }
    };


    $scope.sumaPesoComp = function () {
      //console.log("se suma el peso de esta columna");

      var sum = 0;

      for (var i = 0; i < $scope.compArr.length; i++) {
        var sum1 = angular.element("#PesoCom" + (i + 1)).val();

        if (sum1 !== undefined) {
          sum += parseFloat(sum1);
          var ui = $scope.obtieneUnidadInidice(sum1);
          angular.element("#UIcom" + (i + 1)).val(ui);
        }

        var total = parseFloat(sum) * parseFloat($scope.factorPeso);

        angular.element("#TotalPesoCarga").val(total);

      }
    };


    //valida peso máximo
    $scope.validaPesoMaximo = function (index) {
      //console.log("dentro de peso  máximo" + index);
      var pesoMax = angular.element("#Max" + (index + 1)).val();
      var peso = angular.element("#PesoCom" + (index + 1)).val();
      if(pesoMax===''){
        $scope.Modal(
          "Error",
          "No ha colocado el peso máximo en la sección de compartimentos.",
          "OK"
        );
        angular.element("#PesoCom" + (index + 1)).val(0);
      }else
      if (parseFloat(pesoMax) < parseFloat(peso)) {
        //alert("El peso sobrepasa el valor máximo definido. Peso máximo: " + pesoMax + " < Peso Compartimento: " + peso);
        $scope.Modal(
          "Error",
          "El peso sobrepasa el valor máximo definido. Peso máximo = " + pesoMax + "  <  " + peso + " = Peso Compartimento.",
          "OK");
        var peso = angular.element("#PesoCom" + (index + 1)).val(0);
      }
    };

    //valida peso máximo pasajeros
    $scope.validaPesoMaximoPasajeros = function (index, id) {
      //console.log("dentro de peso  máximo pasajeros");
      var pesoMax = angular.element("#limite").val();
      var peso = angular.element("#total").val();

      //console.log("el peso limite: " + pesoMax + "   peso: " + peso  + "   id: " + id + "   index: " + index);
      if (pesoMax === '') {
        $scope.Modal("Error", "No ha colocado el peso máximo en la sección de pasajeros", "ok");
        angular.element("#" + id + (index + 1)).val(0);
      }
      else
        if (parseFloat(pesoMax) < parseFloat(peso)) {
          //alert("El peso sobrepasa el valor máximo definido. Peso máximo: " + pesoMax + " < Peso Compartimento: " + peso);
          $scope.Modal(
            "Error",
            "El peso sobrepasa el valor máximo definido. Peso máximo = " + pesoMax + "  <  " + peso + " = Peso Compartimento.",
            "OK");
          angular.element("#" + id + (index + 1)).val(0);

          /* angular.element("#AdultoMasculino" + ($scope.cabPasArr.length)).val(0);
          angular.element("#AdultoFemenino" + ($scope.cabPasArr.length)).val(0);
          angular.element("#Ninio" + ($scope.cabPasArr.length)).val(0); */
        }
    };

    //valida peso máximo pesos
    $scope.validaPesoMaximoPesos = function () {
      //console.log("dentro de peso  máximo");
      var PesoCeroMax = angular.element("#PesoCeroMax").val();
      var PesoRampaMax = angular.element("#PesoRampaMax").val();
      var PesoDespegueMax = angular.element("#PesoDespegueMax").val();
      var PesoAterrizajeMax = angular.element("#PesoAterrizajeMax").val();
      var PesoCero = $scope.avionPesos["peso_cero_combustible"];
      var pesoRampa = $scope.avionPesos["peso_rampa"];
      var PesoDespegue = $scope.avionPesos["peso_despegue_tow"];
      var PesoAterrizaje = $scope.avionPesos["peso_aterrizaje"];

      if (PesoCeroMax === '') {
        $scope.Modal(
          "Error",
          "No se ha colocado el peso máximo en peso cero combustible",
          "ok"
        );
      } else if (parseFloat(PesoCeroMax) < parseFloat(PesoCero)) {
        /* alert("El peso sobrepasa el valor máximo definido. Peso máximo: " + pesoMax 
        + " < Peso Compartimento: " + peso); */
        $scope.Modal(
          "Error",
          "El peso sobrepasa el valor máximo definido. Peso máximo = "
          + PesoCeroMax + "  <  " + PesoCero + " = Peso Cero.",
          "OK");
        angular.element("#PesoCeroMax").val(0);
      }
      /* else if(PesoRampaMax===''){
        $scope.Modal(
          "Error",
          "No se ha colocado el peso máximo",
          "ok"
        );
      } */
      else if (PesoDespegueMax === '') {
        $scope.Modal(
          "Error",
          "No se ha colocado el peso máximo en peso despegue",
          "ok"
        );
      } else if (parseFloat(PesoDespegueMax) < parseFloat(PesoDespegue)) {
        /* alert("El peso sobrepasa el valor máximo definido. Peso máximo: " + pesoMax 
        + " < Peso Compartimento: " + peso); */
        $scope.Modal(
          "Error",
          "El peso sobrepasa el valor máximo definido. Peso máximo = "
          + PesoDespegueMax + "  <  " + PesoDespegue + " = Peso Despegue.",
          "OK");
        angular.element("#PesoDespegueMax").val(0);
      } else if (PesoAterrizajeMax === '') {
        $scope.Modal(
          "Error",
          "No se ha colocado el peso máximo en peso aterrizaje",
          "ok"
        );
      } else if (parseFloat(PesoAterrizajeMax) < parseFloat(PesoAterrizaje)) {
        /* alert("El peso sobrepasa el valor máximo definido. Peso máximo: " + pesoMax 
        + " < Peso Compartimento: " + peso); */
        $scope.Modal(
          "Error",
          "El peso sobrepasa el valor máximo definido. Peso máximo = "
          + PesoAterrizajeMax + "  <  " + PesoAterrizaje + " = Peso Aterrizaje.",
          "OK");
        angular.element("#PesoAterrizajeMax").val(0);
      }
    };

    //obtiene los pesos como json y los alamcena en una variable
    $scope.getPesos = function () {

      $http({
        method: 'GET',
        url: '/getPesos',
        params: {
          accion: 'getPesos',
        }
      })
        .then(function successCallback(response) {

          console.log(response);
          $scope.avionesPesos = response.data["avionesPesos"].slice(0, response.data["avionesPesos"].length);
          console.log($scope.avionesPesos);


        }, function errorCallback(response) {
          $scope.limpiarControles();
          $scope.Modal(
            "Error",
            "<h3><span class='badge badge-danger'>Ha ocurrido un error con el servidor.</span></h3>",
            "OK");
        });
    };

    //Muestra un mensaje de error
    $scope.Modal = function (titulo, mensaje, btnVal) {
      var confirm = $mdDialog.confirm()
        .title(titulo)
        .htmlContent(mensaje)
        .ariaLabel('Mensaje')
        .targetEvent(0)
        .ok(btnVal)
        .cancel('Cancelar');
      $mdDialog.show(confirm).then(function () {

      }, function () {

      });
    };

    $scope.limpiarControles = function () {

    };

    //recalcula las unidades índice al colocarse nuevos valores en los atributos correspondientes
    $scope.recacularUnidadIndicePesos = function () {

      var constK = angular.element("#constK").val();
      var constC = angular.element("#constC").val();
      var sta = angular.element("#sta").val();
      var refSta = angular.element("#refsta").val();

      if (constK === '') {
        $scope.Modal(
          "Error",
          "No se ha colocado el valor en const k",
          "OK"
        );
        
      } else if (constC === '' || constC === '0' || parseInt(constC==0)) {
        $scope.Modal(
          "Error",
          "No se ha colocado el valor en const C o es igual a 0",
          "OK"
        );
        
      } else if (sta === '') {
        $scope.Modal(
          "Error",
          "No se ha colocado el valor en sta",
          "OK"
        );
        
      } else if (refSta === '') {
        $scope.Modal(
          "Error",
          "No se ha colocado el valor en ref sta",
          "OK"
        );
        
      } else {
        var ui1 = $scope.obtieneUnidadInidice($scope.avionPesos["peso_operacional"]);
        angular.element("#PesoOperacional2").val(ui1);
        var ui2 = $scope.obtieneUnidadInidice($scope.avionPesos["carga_paga"]);
        angular.element("#CargaPaga2").val(ui2);
        var ui3 = $scope.obtieneUnidadInidice($scope.avionPesos["peso_cero_combustible"]);
        angular.element("#PesoCeroUI").val(ui3);
        var ui4 = $scope.obtieneUnidadInidice($scope.avionPesos["peso_taxi"]);
        angular.element("#CombustibleTaxi2").val(ui4);
        var ui5 = $scope.obtieneUnidadInidice($scope.avionPesos["peso_despegue_tow"]);
        angular.element("#PesoDespegue2").val(ui5);
        var ui6 = $scope.obtieneUnidadInidice($scope.avionPesos["peso_aterrizaje"]);
        angular.element("#PesoAterrizaje2").val(ui6);
      }
    };

    $scope.actualizaPesos = function () {
      var marca = angular.element("#marca").val();
      var modelo = angular.element("#modelo").val();
      var version = angular.element("#version").val();

      //console.log("marca: " + marca + "   modelo: " + modelo + "   version: " + version);
      angular.forEach($scope.avionesPesos, function (val, key) {

        if ($scope.avionesPesos[key]["marca"] === marca) {
          if ($scope.avionesPesos[key]["modelo"] === modelo) {
            if ($scope.avionesPesos[key]["version"] === version) {
              //console.log($scope.avionesPesos[key]);
              //console.log(val);
              $scope.avionPesos = val;
              //console.log($scope.avionPesos);
              $scope.validaPesoMaximoPesos();
              $scope.recacularUnidadIndicePesos();
            }
          }
        }

      });
    };

    $scope.actualizaPesosMaximos = function(){
      var limite = angular.element("#limite").val();
      console.log(limite + "   factorpesomax: " + $scope.factorPesoMax)
      angular.element("#limite").val(parseFloat(limite)*parseFloat($scope.factorPesoMax));
      var pesoCeroMax = angular.element("#PesoCeroMax").val();
      angular.element("#PesoCeroMax").val(parseFloat(pesoCeroMax)*parseFloat($scope.factorPesoMax));
      var PesoDespegueMax = angular.element("#PesoDespegueMax").val();
      angular.element("#PesoDespegueMax").val(parseFloat(PesoDespegueMax)*parseFloat($scope.factorPesoMax));
      var PesoAterrizajeMax = angular.element("#PesoAterrizajeMax").val();
      angular.element("#PesoAterrizajeMax").val(parseFloat(PesoAterrizajeMax)*parseFloat($scope.factorPesoMax));
    };
  }
]);

