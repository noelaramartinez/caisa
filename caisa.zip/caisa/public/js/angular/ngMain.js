var app = angular.module('App', ['ngMaterial', 'ngSanitize']);

app.config(['$interpolateProvider', function ($interpolateProvider) {
  $interpolateProvider.startSymbol('<%');
  $interpolateProvider.endSymbol('%>');
}]);

app.controller('Controller1', [
  "$scope",
  "$http",
  "$mdDialog",
  "$timeout",
  "$window",
  function ($scope, $http, $mdDialog, $timeout, $window) {

    $scope.a = "";
    $scope.b = "";
    $scope.fechaI = new Date();
    $scope.temporada = "";
    $scope.index = 0;
    $scope.cabPasArr = [{ "cabP" : { "M": "", "F": "", "N": "", "A": 1, "P": "", "UI": "" } }];
    $scope.compArr = [{ "comp" : { "max":"", "A":1, "peso":"", "UI":""}}]


    //se ejecuta al cargarse completamente la página
    angular.element(function () {
      var dateA = angular.element("#fechaesperada").val();
      if(dateA!==undefined)
      $scope.cambioFecha();
      $scope.getPesos();
    });

    /**
     * Valida la fecha que se ingresa y asigna un valor al campo temporada
     */
    $scope.cambioFecha = function () {
      var dateA = angular.element("#fechaesperada").val();
      var arrTmp = dateA.split("-");
      $scope.a = arrTmp[2] + "-" + arrTmp[1] + "-" + arrTmp[0];
      $scope.limiteA = "01-05-" + arrTmp[0];
      $scope.limiteB = "31-10-" + arrTmp[0];
      $scope.c = moment($scope.a, "DD-MM-YYYY");
      $scope.d = moment($scope.limiteA, "DD-MM-YYYY");
      $scope.e = moment($scope.limiteB, "DD-MM-YYYY");
      //console.log($scope.limiteA + "       " + $scope.limiteB + "    " + $scope.a);

      if ($scope.c.isSameOrAfter($scope.d) && $scope.c.isSameOrBefore($scope.e)) {
        //console.log($scope.c + ' es verano   ' + $scope.d + "    " + $scope.e);
        $scope.temporada = "VERANO";
        angular.element("#temporada").val("VERANO");
      } else {
        //console.log($scope.c + ' es invierno   ' + $scope.d + "    " + $scope.e);
        $scope.temporada = "INVIERNO";
        angular.element("#temporada").val("INVIERNO");
      }
    };

    /**
     * Agrega un conjunto de resgistros con todos los campos para la cabina de pasajeros
     */
    $scope.agregaCabPas = function () {

      var i = $scope.cabPasArr[$scope.cabPasArr.length-1]["cabP"]["A"];
      var aux = { "cabP": { "M": "", "F": "", "N": "", "A": (++i), "P": "", "UI": "" } };
      $scope.cabPasArr.push(
        aux
      );
      //console.log(aux);
      //console.log($scope.cabPasArr);
    };

    /**
     * Elimina un conjunto de resgistros con todos los campos para la cabina de pasajeros
     */
    $scope.eliminaCabPas = function () {
      //console.log("la longitud es: " + $scope.cabPasArr.length);

      if ($scope.cabPasArr.length > 1) {
        var aux = $scope.cabPasArr.slice(
          0, $scope.cabPasArr.length - 1
        );

        $scope.cabPasArr.length = 0;
        $scope.cabPasArr = aux.slice(0);
        aux.length = 0;
      }

      for(var i=0;i<3;i++){
        $scope.sumaPesoCol(i);
      }

      //console.log($scope.cabPasArr);
      //console.log(aux);
    };

    /**
     * Agrega un conjunto de resgistros con todos los campos para el compartimiento
     */
    $scope.agregaComp = function () {
      var i = $scope.compArr[$scope.compArr.length-1]["comp"]["A"];
      var aux = { "comp" : { "max":"", "A":(++i), "Peso":"", "UI":""}};
      
      if($scope.compArr.length<5)
      $scope.compArr.push(
        aux
      );
      //console.log(aux);
      //console.log($scope.cabPasArr);
    };

    /**
     * Elimina un conjunto de resgistros con todos los campos para el compartimiento
     */
    $scope.eliminaComp = function () {
      //console.log("la longitud es: " + $scope.compArr.length);

      if ($scope.compArr.length > 1) {
        var aux = $scope.compArr.slice(
          0, $scope.compArr.length - 1
        );

        $scope.compArr.length = 0;
        $scope.compArr = aux.slice(0);
        aux.length = 0;
      }

      //console.log($scope.compArr);
      //console.log(aux);
    };


    /**
     * Suma el peso total de todas las columnas por fila
     */
    $scope.sumaPesoFila = function (fila) {

      var sum1 = angular.element("#AdultoMasculino" + (fila+1)).val();
      
      var sum2 = angular.element("#AdultoFemenino" + (fila+1)).val();
      
      var sum3 = angular.element("#Ninio" + (fila+1)).val();
      
      if(sum1===undefined || sum1 === null || sum1 === "" || sum1===NaN || sum1==='NaN'){
        sum1 = 0;
      }
      if(sum2===undefined || sum2 === null || sum2 === "" || sum2===NaN || sum2==='NaN'){
        sum2 = 0;
      }
      if(sum3===undefined || sum3 === null || sum3 === "" || sum3===NaN || sum3==='NaN'){
        sum3 = 0;
      }

      var sumaTotal = parseFloat(sum1) + parseFloat(sum2) + parseFloat(sum3);
      
      angular.element("#Peso" + (fila+1)).val(parseFloat(sumaTotal));
      
    };

    /**
     * Suma el peso total de todas los campos de una sola columna
     */
    $scope.sumaPesoCol = function (col) {
      //console.log("se suma el peso de esta columna");

      var sumHom = 0;
      var sumMuj = 0;
      var sumNin = 0;

      for(var i=0;i<$scope.cabPasArr.length;i++){
        var sum1 = angular.element("#AdultoMasculino" + (i+1)).val();
        var sum2 = angular.element("#AdultoFemenino" + (i+1)).val();
        var sum3 = angular.element("#Ninio" + (i+1)).val();

        if(sum1!==undefined){
          sumHom += parseFloat(sum1);
        }
        if(sum2!==undefined){
          sumMuj += parseFloat(sum2);
        }
        if(sum3!==undefined){
          sumNin += parseFloat(sum3);
        }


        var totaTotales = parseFloat(sumHom) + parseFloat(sumMuj) + parseFloat(sumNin);

        angular.element("#t1").val(sumHom);
        angular.element("#t2").val(sumMuj);
        angular.element("#t3").val(sumNin);
        angular.element("#total").val(totaTotales);

      }
    };

    $scope.getPesos = function(){

      $http({
        method: 'GET',
        url: '/getPesos',
        params: {
          accion: 'getPesos',
          
        }
      })
      .then(function successCallback(response) {

        console.log(response);
/*         var marca = response["avionesPesos"][0][0];
        var modelo = response["avionesPesos"][0][1];
        var version = response["avionesPesos"][0][2];
 */
        //console.log("marca " + marca + "   modelo: " + modelo + "   vresion: " + version);

        /* angular.forEach($scope.arrTargets, function (val, key) {
          if (val[1]) {
            if (status == 1) {
              val[0].setAttribute("fill", colorOcupado);
            } else {
              val[0].setAttribute("fill", colorReservado);
            }
          }
        }); */


        //location.href = "mesas";

      }, function errorCallback(response) {
        //$scope.limpiarControles();
        $scope.errorModal(
          "Error",
          "<h3><span class='badge badge-danger'>Ha ocurrido un error con el servidor.</span></h3>",
          "OK");
      });
    };

    //Muestra un mensaje de error
    $scope.errorModal = function (titulo, mensaje, btnVal) {
      var confirm = $mdDialog.confirm()
        .title(titulo)
        .htmlContent(mensaje)
        .ariaLabel('Mensaje')
        .targetEvent(0)
        .ok(btnVal)
        .cancel('Cancelar');
      $mdDialog.show(confirm).then(function () {

      }, function () {

      });
    };

    $scope.limpiarControles = function(){

    };
  }
]);

