<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AvionesPesos extends Model
{
    //

    protected $table = 'aviones_pesos';
}
