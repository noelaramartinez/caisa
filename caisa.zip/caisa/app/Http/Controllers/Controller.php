<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\Request;
use DB;
use View;
use Log;
use App\AvionesPesos;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    function getPesos(){

        Log::info("dentro del controlador");
         
            //$avionesPesos = AvionesPesos::all();

            $avionesP = DB::table('aviones_pesos')
            ->select('aviones_pesos.*')
            ->orderBy('id', 'asc')
            ->get();

        return response()->json([
            'avionesPesos' => $avionesP
        ]); 
    }

    function regPesoBal(Request $request){

        $data = request()->all();

        $ap = new AvionesPesos;
        $ap->marca = $data["marca"];
        $ap->modelo = $data["Modelo1"];
        $ap->version = $data["version"];
        $ap->peso_taxi = $data["MTW"];
        $ap->peso_operacional = $data["MTW"];
        $ap->carga_paga = $data["MTW"];
        $ap->peso_despegue_tow = $data["MTOW"];
        $ap->peso_aterrizaje = $data["MZFW"];
        $ap->peso_cero_combustible = $data["MZFW"];

        $ap->save();
        return View::make('regPesoBalan', ['response' => $ap->marca]);
    }

    function regFlight(Request $request){

        $data = request()->all();

        $ap = new Flight;
        $ap->mac = $data["MAC"];
        $ap->lemac = $data["LEMAC"];
        $ap->constK = $data["CONSTK"];
        $ap->constC = $data["CONSTC"];
        $ap->sta = $data["STA"];
        $ap->refSta = $data["REFSTA"];
        
        $ap->save();
        return View::make('regPesoBalan', ['response' => $ap->mac]);
    }

    function regCentroide(Request $request){

        $data = request()->all();

        $ap = new Centroide;
        $ap->comp1 = $data["CC1"];
        $ap->comp2 = $data["CC2"];
        $ap->comp3 = $data["CC3"];
        $ap->comp4 = $data["CC4"];
        $ap->comp5 = $data["CC5"];
        
        $ap->save();
        return View::make('regPesoBalan', ['response' => $ap->marca]);
    }
}
