<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use DB;
use View;
use Log;
use App\AvionesPesos;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;


    function getPesos(){

        Log::info("dentro del controlador");
         //$avionesPesosAll = AvionesPesos::all();
         /* $avionesPesos = DB::table('aviones_pesos')
            ->select('aviones_pesos.*')
            ->get(); */

            /* $reservaciones = DB::table('reservacion')
            ->join('asiento', 'asiento.id_reservacion', '=', 'reservacion.id')
            ->select('asiento.*', 'reservacion.*')
            ->orderBy('id_mesa', 'asc')
            ->orderBy('id_silla', 'asc')
            ->get(); */


        return response()->json([
            'avionesPesos' => 'avionesPesos'
        ]); 
    }
}
