 <?php $__env->startSection('title', 'manPesoBalan'); ?> <?php $__env->startSection('navbar'); ?> ##parent-placeholder-c63e3c1cfa2ff651ad4cfadea3e21265ffcf8ca3##
<?php $__env->stopSection(); ?> <?php $__env->startSection('contenido'); ?>
<style>
#miTablaPersonalizada th{
  width: 100%;
  overflow: auto;
}
</style>


<div class="container text-center">

  <form action="" method="POST" id="formWeigthBalance" name="formWeigthBalance">
    <h1>Manifiesto de peso balance</h1>
    <span class="form-group text-center">
      <table id="miTablaPersonalizada" class="table table-borderless table-striped text-center table-condensed">
        <thead>
          <tr>
            <td colspan="4">
              <h3 class="text-info">Weight&nbsp;&amp;&nbsp;Balance</h3>
            </td>
          </tr>
        </thead>
        <tbody>
          <tr class="text-left">
            <td>
              <span class="">
                Tiempo estimado de salida (ETD):
              </span>
              <input style="width: 100%;" type="text" required="required" class="form-control is-valid" id="ETD" name="EDT"
                placeholder="" />
            </td>

            <td>
              <span class="">Temporada:</span>
              <select name="temporada" class="form-control is-valid" id="temporada">
                <option>Invierno</option>
                <option>Verano</option>
              </select>
            </td>

            <td>
              <span class="">Aeronave:</span>
              <input style="width: 100%;" type="text" required="required" class="form-control is-valid" id="aeronave" name="aeronave"
                placeholder="" />
            </td>

            <td>
              <span class="">Peso&nbsp;en:</span>
              <select name="pesoEn" class="form-control is-valid" id="pesoEn">
                <option>KG</option>
                <option>LB</option>
              </select>
            </td>
          </tr>

          <tr class="text-left">
            <!-- fila 2 -->
            <td>
              <span class="">Vuelo&nbsp;HCP&nbsp;Numero:</span>
              <input type="text" required="required" class="form-control is-valid" id="validationServer01" name="vueloHCP"
                placeholder="No. de Vuelo" value="" size="10" />
            </td>

            <td>
              <span class="">Fecha:</span>
              <input type="date" name="fechaesperada" class="form-control is-valid" id="fechaesperada"/>
            </td>

            <td>
              <span class="">De:</span>
              <input type="text" required="required" class="form-control is-valid" id="origen" placeholder="Origen" name="origen"
                value="" size="10" />
            </td>

            <td>
              <span class="">A:</span>
              <input type="text" required="required" class="form-control is-valid" id="destino" placeholder="Destino" name="destino"
                value="" size="10" />
            </td>
          </tr>
          <!-- fila 3 -->
          <tr class="text-left">
            <td >
              <span class="">Matrícula&nbsp;XA:</span>
              <input type="text" required="required" class="form-control is-valid" id="mtriculaXA" placeholder="" name="matriculaXA"
                value="" size="10" />
            </td>
            <td>
              <span class="">Pista:</span>
              <input type="text" required="required" class="form-control is-valid" id="pista" placeholder="" value="" name="pista"
                size="10"/>
            </td>
            
            <td>
                <span class="">MAC:</span>
                <input style="width: 100%;" type="text" required="required" class="form-control is-valid" id="MAC" name="MAC"
                  placeholder="" />
              </td>
              <td>
                <span class="">LEMAC:</span>
                <input style="width: 100%;" type="text" required="required" class="form-control is-valid" id="LEMAC" name="LEMAC"
                  placeholder="" />
              </td>
          </tr>
          <!-- Segundo bloque -->
          <tr class="text-left">
            <td>
              <span class="">Const. K:</span>
              <input style="width: 100%;" type="text" required="required" class="form-control is-valid" id="constK" name="constK"
                placeholder="" />
            </td>
            <td>
              <span class="">Const. C:</span>
              <input style="width: 100%;" type="text" required="required" class="form-control is-valid" id="constC" name="constC"
                placeholder="" />
            </td>
            <td >
                <span class="">Sta:</span>
                <input type="text" required="required" class="form-control is-valid" id="sta" placeholder="" value="" name="sta"
                  size="10" />
              </td>
              <td >
                <span class="">Ref.&nbsp;Sta:</span>
                <input type="text" required="required" class="form-control is-valid" id="refsta" placeholder="" value="" name="refsta"
                  size="10" />
              </td>
          </tr>
          <tr class="text-left">
              <td>
                  <span class=""><b>MZFW+Comb</b>(MZFW+FOB)&nbsp;<b>A</b>:</span>
                  <input type="text" required="required" class="form-control is-valid" id="mzfw" placeholder="" name="mzfw"
                    value="" size="10" />
              </td>  
              <td>
                  <span class=""><b>An.&nbsp;Pista</b>(Awy.&nbsp;Analysis)&nbsp;<b>B</b>:</span>
                  <input type="text" required="required" class="form-control is-valid" id="anpista" placeholder="" name="anpista"
                    value="" size="10" />
              </td>  
              <td>
                  <span class=""><b>MLW+CdC</b>(MLW+TF)&nbsp;<b>A</b>:</span>
                  <input type="text" required="required" class="form-control is-valid" id="mlw" placeholder="" name="mlw"
                    value="" size="10" />
              </td>  
              <td>
                <div class="row">
                  <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                      <span class="">Temp.:</span>
                      <input type="text" required="required" class="form-control is-valid" id="temp" placeholder="" name="temp"
                        value="" size="5" />
                  </div>
                  <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                      <span class="">Flaps:</span>
                      <input type="text" required="required" class="form-control is-valid" id="flaps" placeholder="" name="flaps"
                        value="" size="5" />
                  </div>
                </div>
              </td>
          </tr>


          
          <!-- Fin Segundo bloque -->
        </tbody>
      </table>

      <!-- tabla Cabina de pasajeros -->
      <table class="table table-borderless table-striped text-center">
        <thead>
          <tr>
            <td colspan="6">
              <h3 class="text-info">Cabina&nbsp;de&nbsp;Pasajeros</h3>
            </td>
          </tr>
          <tr>
            <td>
              Adultos&nbsp;Masculino
            </td>
            <td>
              Adultos&nbsp;Femenino
            </td>
            <td>
              Ni&ntilde;os
            </td>
            <td></td>
            <td>
              Peso
            </td>
            <td>
              Unidad&nbsp;&Iacute;ndice
            </td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <input type="text" class="form-control is-valid" required="required" name="AdultoMasculinoA" id="AdultoMasculinoA" placeholder="" />
            </td>
            <td>
              <input type="text" required="required" name="AdultoFemeninoA" id="AdultoFemeninoA" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="NinioA" id="NininoA" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              A
            </td>
            <td>
              <input type="text" required="required" name="PesoA" id="PesoA" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="UnidadInA" id="UnidadInA" placeholder="" class="form-control is-valid"/>
            </td>
          </tr>
          <tr>
            <td>
              <input type="text" required="required" name="AdultoMasculinoB" id="AdultoMasculinoB" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="AdultoFemeninoB" id="AdultoFemeninoB" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="NinioB" id="NininoB" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              B
            </td>
            <td>
              <input type="text" required="required" name="PesoB" id="PesoB" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="UnidadInB" id="UnidadInB" placeholder="" class="form-control is-valid"/>
            </td>
          </tr>
          <tr>
            <td>
              <input type="text" required="required" name="AdultoMasculinoC" id="AdultoMasculinoC" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="AdultoFemeninoC" id="AdultoFemeninoC" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="NinioC" id="NininoC" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              C
            </td>
            <td>
              <input type="text" required="required" name="PesoC" id="PesoC" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="UnidadInC" id="UnidadInC" placeholder="" class="form-control is-valid"/>
            </td>
          </tr>
          <tr>
            <td>
              <input type="text" required="required" name="AdultoMasculinoD" id="AdultoMasculinoD" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="AdultoFemeninoD" id="AdultoFemeninoD" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="NinioD" id="NininoD" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              D
            </td>
            <td>
              <input type="text" required="required" name="PesoD" id="PesoD" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="UnidadInD" id="UnidadInD" placeholder="" class="form-control is-valid"/>
            </td>
          </tr>
          <tr>
            <td>
              <input type="text" required="required" name="AdultoMasculinoE" id="AdultoMasculinoE" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="AdultoFemeninoE" id="AdultoFemeninoE" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="NinioE" id="NininoE" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              E
            </td>
            <td>
              <input type="text" required="required" name="PesoE" id="PesoE" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="UnidadInE" id="UnidadInE" placeholder="" class="form-control is-valid"/>
            </td>
          </tr>
          <tr>
            <td>
              <input type="text" required="required" name="AdultoMasculinoF" id="AdultoMasculinoF" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="AdultoFemeninoF" id="AdultoFemeninoF" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="NinioF" id="NininoF" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              F
            </td>
            <td>
              <input type="text" required="required" name="PesoF" id="PesoF" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="UnidadInF" id="UnidadInF" placeholder="" class="form-control is-valid"/>
            </td>
          </tr>

          <tr>
            <td>
              <input type="text" id="t1" class="form-control is-valid" name="t1"/>
            </td>
            <td>
              <input type="text" id="t2" class="form-control is-valid" name="t2"/>
            </td>
            <td>
              <input type="text" id="t3" class="form-control is-valid" name="t3"/>
            </td>
            <td>
              <b>TOTAL</b>
            </td>
            <td colspan="2">
                <input type="text" id="total" class="form-control is-valid" name="total"/>
            </td>
            
          </tr>
        </tbody>
      </table>
      <!-- fin tabla Cabina de pasajeros -->

      <!-- tabla Compartimiento -->
      <table name="Compartimiento" id="ocmpartimiento" class="table table-borderless table-striped text-center">
        <thead>
          <tr>
            <td colspan="4">
              <h3 class="text-info">Compartimiento</h3>
            </td>
          </tr>
          <tr>
            <td>
              Max
            </td>
            <td></td>
            <td>
              Peso
            </td>
            <td>Unidad&nbsp;&Iacute;ndice</td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <input type="text" required="required" name="Max1" id="Max1" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              1
            </td>
            <td>
              <input type="text" required="required" name="PesoCom1" id="PesoCom1" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="UIcom1" id="UIcom1" placeholder="" class="form-control is-valid"/>
            </td>
          </tr>
          <tr>
            <td>
              <input type="text" required="required" name="Max2" id="Max2" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              2
            </td>
            <td>
              <input type="text" required="required" name="PesoCom2" id="PesoCom2" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="UIcom2" id="UIcom2" placeholder="" class="form-control is-valid"/>
            </td>
          </tr>
          <tr>
            <td>
              <input type="text" required="required" name="Max3" id="Max3" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              3
            </td>
            <td>
              <input type="text" required="required" name="PesoCom3" id="PesoCom3" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="UIcom3" id="UIcom3" placeholder="" class="form-control is-valid"/>
            </td>
          </tr>
          <tr>
            <td>
              <input type="text" required="required" name="Max4" id="Max4" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              4
            </td>
            <td>
              <input type="text" required="required" name="PesoCom4" id="PesoCom4" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="UIcom4" id="UIcom4" placeholder="" class="form-control is-valid"/>
            </td>
          </tr>
          <tr>
            <td>
              <input type="text" required="required" name="Max5" id="Max5" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              5
            </td>
            <td>
              <input type="text" required="required" name="PesoCom5" id="PesoCom5" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="UIcom5" id="UIcom5" placeholder="" class="form-control is-valid"/>
            </td>
          </tr>

          <tr>
            <td></td>
            <td>
              <span class="">
                <b>Total&nbsp;Carga&nbsp;Paga:</b>
              </span>
            </td>
            <td>
              <input type="text" required="required" name="TotalPesoCarga" id="TotalPesoCarga" placeholder="" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="UIpaga" id="UIpaga" placeholder="" class="form-control is-valid"/>
            </td>
          </tr>
        </tbody>
      </table>
      <!-- fin tabla Compartimiento -->

      <!-- tabla pesos final -->

      <table name="pesosFinal" id="pesosFinal" class="table table-borderless table-striped text-center">
        <thead>
          <tr>
            <td colspan="4">
              <h3 class="text-info">Pesos</h3>
            </td>
          </tr>
          <tr>
            <td></td>
            <td>
              Peso&nbsp;Actual
            </td>
            <td>
              Unidad&nbsp;&Iacute;ndice
            </td>
            <td>
              Peso&nbsp;M&aacute;ximo
            </td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td class="text-right">
              <label for="PesoVacio1" class="">Peso Vacio (EW):</label>
            </td>
            <td>
              <input type="text" required="required" name="PesoVacio1" id="PesoVacio1" placeholder="Peso Actual" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="PesoVacio2" id="PesoVacio2" placeholder="Unidad Indice" class="form-control is-valid"/>
            </td>
            <td></td>
          </tr>
          <tr>
            <td class="text-right">
              <label for="PesoOperacional1" class="">Peso&nbsp;Operacional(OW):</label>
            </td>
            <td>
              <input type="text" required="required" name="PesoOperacional1" id="PesoOperacional1"
                placeholder="Peso Actual" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="PesoOperacional2" id="PesoOperacional2"
                placeholder="Unidad Indice" class="form-control is-valid"/>
            </td>
            <td></td>
          </tr>
          <tr>
            <td class="text-right">
              <label for="CargaPaga1" class="">Carga&nbsp;de&nbsp;Paga(Pay Load):</label>
            </td>
            <td>
              <input type="text" required="required" name="CargaPaga1" id="CargaPaga1" placeholder="Peso Actual" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="CargaPaga2" id="CargaPaga2" placeholder="Unidad Indice" class="form-control is-valid"/>
            </td>
            <td></td>
          </tr>
          <tr>
            <td class="text-right">
              <label for="PesoCero1" class="">Peso&nbsp;Cero&nbsp;Combustible(ZFW):</label>
            </td>
            <td>
              <input type="text" required="required" name="PesoCero1" id="PesoCero1" placeholder="Peso Actual" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="PesoCero2" id="PesoCero2" placeholder="Unidad Indice" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="PesoCeroMax" id="PesoCeroMax" placeholder="Peso Máximo" class="form-control is-valid"/>
            </td>
          </tr>
          <tr>
            <td class="text-right">
              <label for="CombustibleDespegue1" class="">Combustible&nbsp;al&nbsp;Despegue(FOB):</label>
            </td>
            <td>
              <input type="text" required="required" name="CombustibleDespegue1" id="CombustibleDespegue1"
                placeholder="Peso Actual" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="CombustibleDespegue2" id="CombustibleDespegue2"
                placeholder="Unidad Indice" class="form-control is-valid"/>
            </td>
            <td></td>
          </tr>

          <tr>
            <td class="text-right">
              <label for="PesoRampa1" class="">Peso&nbsp;en&nbsp;Rampa(RW):</label>
            </td>
            <td>
              <input type="text" required="required" name="PesoRampa1" id="PesoRampa1" placeholder="Peso Actual" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="PesoRampa2" id="PesoRampa2" placeholder="Unidad Indice" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="PesoRampaMax" id="PesoRampaMax" placeholder="Peso Máximo" class="form-control is-valid"/>
            </td>
          </tr>

          <tr>
            <td class="text-right">
              <label for="CombustibleTaxi1" class="">Combustible&nbsp;de&nbsp;Taxi(TW):</label>
            </td>
            <td>
              <input type="text" required="required" name="CombustibleTaxi1" id="CombustibleTaxi1"
                placeholder="Peso Actual" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="CombustibleTaxi2" id="CombustibleTaxi2"
                placeholder="Unidad Indice" class="form-control is-valid"/>
            </td>
            <td>

            </td>
          </tr>


          <tr>
            <td class="text-right">
              <label for="PesoDespegue1" class="">Peso&nbsp;Despegue(TOW):</label>
            </td>
            <td>
              <input type="text" required="required" name="PesoDespegue1" id="PesoDespegue1"
                placeholder="Peso Actual" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="PesoDespegue2" id="PesoDespegue2"
                placeholder="Unidad Indice" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="PesoDespegueMax" id="PesoDespegueMax"
                placeholder="Peso Máximo" class="form-control is-valid"/>
            </td>
          </tr>


          <tr>
            <td class="text-right">
              <label for="ConsumoCombustible1" class="">Consumo&nbsp;de&nbsp;Combustible(TF):</label>
            </td>
            <td>
              <input type="text" required="required" name="ConsumoCombustible1" id="ConsumoCombustible1"
                placeholder="Peso Actual" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="ConsumoCombustible2" id="ConsumoCombustible2"
                placeholder="Unidad Indice" class="form-control is-valid"/>
            </td>
            <td>

            </td>
          </tr>


          <tr>
            <td class="text-right">
              <label for="PesoAterrizaje1" class="">Peso&nbsp;Aterrizaje(LW):</label>
            </td>
            <td>
              <input type="text" required="required" name="PesoAterrizaje1" id="PesoAterrizaje1"
                placeholder="Peso Actual" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="PesoAterrizaje2" id="PesoAterrizaje2"
                placeholder="Unidad Indice" class="form-control is-valid"/>
            </td>
            <td>
              <input type="text" required="required" name="PesoAterrizajeMax" id="PesoAterrizajeMax"
                placeholder="Peso Máximo" class="form-control is-valid"/>
            </td>
          </tr>


        </tbody>
      </table>

      <!-- fin tabla pesos final -->
      <p><button class="btn btn-primary btn-block" type="submit" name="Calcular" id="Calcular"  >Calcular</button></p>
    </span>

  </form>

  <div class="form-row">
    <div class="col-md-4 mb-3">
      <h2>
        Estabilizador
        <input type="text" required="required" class="form-control is-valid" id="validationServer" placeholder=""
          value="" size="10" class="form-control is-valid"/>
      </h2>
      <p>&nbsp;</p>
      <p>
        <img src="../Documentos/untitled.png" alt="" width="857" height="757" />
      </p>
      <p>&nbsp;</p>
    </div>
  </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>