@extends('index') @section('title', 'regPesoBalan') @section('navbar') @parent
@endsection @section('contenido')

<div class="container text-center">
  <h1>Registrar peso balance</h1>

  <form action="" method="POST" id="form1" name="form1">
    <div
      class="row text-left"
      style="background-color: #eeeeee; padding: 10px 0 10px;"
    >
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="Matricula1">Matricula:</label>
        <input
          type="text"
          required="required"
          name="Matricula1"
          id="Matricula1"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="Servicio1">Tipo&nbsp;de&nbsp;Servicio:</label>
        <input
          type="text"
          required="required"
          name="Servicio1"
          id="Servicio1"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="Modelo1">Modelo:</label>
        <input
          type="text"
          required="required"
          name="Modelo1"
          id="Modelo1"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="Serie1">Serie:</label>
        <input
          type="text"
          required="required"
          name="Serie1"
          id="Serie1"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
    </div>

    <!-- fila 2 -->

    <div
      class="row text-left"
      style="background-color: #ffffff; padding: 10px 0 10px;"
    >
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="MTW">MTW:</label>
        <input
          type="text"
          required="required"
          name="MTW"
          id="MTW"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="MTOW">MTOW:</label>
        <input
          type="text"
          required="required"
          name="MTOW"
          id="MTOW"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="MLW">MLW:</label>
        <input
          type="text"
          required="required"
          name="MLW"
          id="MLW"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="MZFW">MZFW:</label>
        <input
          type="text"
          required="required"
          name="MZFW"
          id="MZFW"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
    </div>

    <!-- fin fila 2 -->

    <div
      class="row text-left"
      style="background-color: #eeeeee; padding: 10px 0 10px;"
    >
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="PSO">PSO:</label>
        <input
          type="text"
          required="required"
          name="PSO"
          id="PSO"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="CG">C.G:</label>
        <input
          type="text"
          required="required"
          name="CG"
          id="CG"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="UI">UI:</label>
        <input
          type="text"
          required="required"
          name="UI"
          id="UI"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
    </div>
    <br />
    <div class="row text-center">
      <div
        class="col-xs-12 col-sm-12 offset-md-3 col-md-6 offset-lg-3 col-lg-6"
      >
        <button
          type="submit"
          class="btn btn-info"
          id="btn1"
          name="btn1"
          style="width: 100%;"
        >
          Guardar
        </button>
      </div>
    </div>
  </form>

  <br />
  <br />
  <!-- fila 3 -->
  <form action="" method="POST" id="form2" name="form2">
    <div
      class="row text-left"
      style="background-color: #eeeeee; padding: 10px 0 10px;"
    >
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="MAC">MAC:</label>
        <input
          type="text"
          required="required"
          name="MAC"
          id="MAC"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="LEMAC">LEMAC:</label>
        <input
          type="text"
          required="required"
          name="LEMAC"
          id="LEMAC"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="CONSTK">CONSTK:</label>
        <input
          type="text"
          required="required"
          name="CONSTK"
          id="CONSTK"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="CONSTC">CONSTC:</label>
        <input
          type="text"
          required="required"
          name="CONSTC"
          id="CONSTC"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
    </div>

    <!-- fin fila 3 -->

    <!-- fila 4 -->
    <div
      class="row text-left"
      style="background-color: #ffffff; padding: 10px 0 10px;"
    >
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="STA">Sta:</label>
        <input
          type="text"
          required="required"
          name="STA"
          id="STA"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="REFSTA">Ref.&nbsp;Sta:</label>
        <input
          type="text"
          required="required"
          name="REFSTA"
          id="REFSTA"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
    </div>
    <br />
    <div class="row text-center">
      <div
        class="col-xs-12 col-sm-12 offset-md-3 col-md-6 offset-lg-3 col-lg-6"
      >
        <button
          type="submit"
          class="btn btn-info"
          id="btn2"
          name="btn2"
          style="width: 100%;"
        >
          Guardar
        </button>
      </div>
    </div>
  </form>
  <!-- fin fila 4 -->

  <br />
  <br />

  <!-- fila 5 -->
  <form action="" method="POST" id="form3" name="form3">
    <div
      class="row text-left"
      style="background-color: #eeeeee; padding: 10px 0 10px;"
    >
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="CC1">Centroide&nbsp;Compartimiento1:</label>
        <input
          type="text"
          required="required"
          name="CC1"
          id="CC1"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="CC2">Centroide&nbsp;Compartimiento2:</label>
        <input
          type="text"
          required="required"
          name="CC2"
          id="CC2"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="CC3">Centroide&nbsp;Compartimiento3:</label>
        <input
          type="text"
          required="required"
          name="CC3"
          id="CC3"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="CC4">Centroide&nbsp;Compartimiento4:</label>
        <input
          type="text"
          required="required"
          name="CC4"
          id="CC4"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
    </div>
    <!-- fin fila 5 -->

    <!-- fila 6 -->

    <div
      class="row text-left"
      style="background-color: #ffffff; padding: 10px 0 10px;"
    >
      <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
        <label for="CC5">Centroide&nbsp;Compartimiento5:</label>
        <input
          type="text"
          required="required"
          name="CC5"
          id="CC5"
          placeholder=""
          size="10"
          class="form-control is-valid"
        />
      </div>
    </div>
    <br/>
    <div class="row text-center">
      <div
        class="col-xs-12 col-sm-12 offset-md-3 col-md-6 offset-lg-3 col-lg-6"
      >
        <button
          type="submit"
          class="btn btn-info"
          id="btn3"
          name="btn3"
          style="width: 100%;"
        >
          Guardar
        </button>
      </div>
    </div>
    <!-- fin fila 6 -->
  </form>
</div>
@endsection
