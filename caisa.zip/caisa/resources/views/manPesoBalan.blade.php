@extends('index') @section('title', 'manPesoBalan') @section('navbar') @parent
@endsection @section('contenido')
<style>
  #miTablaPersonalizada th {
    width: 100%;
    overflow: auto;
  }
</style>


<div class="container text-center">

  <form action="" method="POST" id="formWeigthBalance" name="formWeigthBalance">
    <h1>Manifiesto de peso balance</h1>
    <span class="form-group text-center">

      <h3 class="text-info">Weight&nbsp;&amp;&nbsp;Balance</h3>

      <!-- Fila 1 -->
      <div class="row text-left" style="background-color: #eeeeee; padding: 10px 0 10px;">
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <label for="ETD">Tiempo&nbsp;estimado&nbsp;de&nbsp;salida&nbsp;(ETD):</label>
          <input style="width: 100%;" type="text" required="required" class="form-control is-valid" id="ETD" name="ETD"
            placeholder="" />
        </div>
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <label for="temporada">Temporada:</label>
          <input style="width: 100%;" type="text" required="required" ng-model="temporada" class="form-control is-valid"
            id="temporada" name="temporada" placeholder="" value="<%temporada%>" disabled ngChange="modificaPeso()" />
        </div>
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <label for="aeronave">Aeronave:</label>
          <input style="width: 100%;" type="text" required="required" class="form-control is-valid" id="aeronave"
            name="aeronave" placeholder="" />

        </div>
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <label for="pesoEn">Peso&nbsp;en:</label>
          <select name="pesoEn" class="form-control is-valid" id="pesoEn" 
          ng-options="option.name for option in data.opcionesPesos track by option.id"
          ng-model="data.pesoSeleccionado"
          ng-change="actualizaPesoEn(data.pesoSeleccionado)"
          >
            
          </select>
        </div>
      </div>
      <!-- Fin fila 1 -->

      <!-- Fila 2 -->
      <div class="row text-left" style="background-color: #ffffff; padding: 10px 0 10px;">
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <label for="MTW">Vuelo&nbsp;HCP&nbsp;Numero:</label>
          <input type="text" required="required" class="form-control is-valid" id="validationServer01" name="vueloHCP"
            placeholder="No. de Vuelo" value="" size="10" />
        </div>
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <label for="fechaesperada">Fecha:</label>
          <input type="date" name="fechaesperada" class="form-control is-valid" id="fechaesperada" ng-model="fechaI"
            ng-change="cambioFecha()" />
        </div>
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <label for="origen">De:</label>
          <input type="text" required="required" class="form-control is-valid" id="origen" placeholder="Origen"
            name="origen" value="" size="10" />

        </div>
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <label for="destino">A:</label>
          <input type="text" required="required" class="form-control is-valid" id="destino" placeholder="Destino"
            name="destino" value="" size="10" />

        </div>
      </div>

      <!-- Fin fila 2 -->

      <!-- Fila 3 -->
      <div class="row text-left" style="background-color: #eeeeee; padding: 10px 0 10px;">
        <!-- <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <label for="matricula">Matrícula:</label>
          <input type="text" required="required" class="form-control is-valid" id="mtriculaXA" placeholder=""
            name="matricula" value="" size="10" />
        </div>
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <label for="MAC">MAC:</label>
          <input style="width: 100%;" type="text" required="required" class="form-control is-valid" id="MAC" name="MAC"
            placeholder="" />

        </div>
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <label for="LEMAC">LEMAC:</label>
          <input style="width: 100%;" type="text" required="required" class="form-control is-valid" id="LEMAC"
            name="LEMAC" placeholder="" />

        </div> -->
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <label for="marca">Marca:</label>
          <input type="text" required="required" class="form-control is-valid" id="marca" placeholder="" name="marca"
            value="" size="10" />
        </div>
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <label for="modelo">Modelo:</label>
          <input style="width: 100%;" type="text" required="required" class="form-control is-valid" id="modelo"
            name="modelo" placeholder="" />

        </div>
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <label for="version">Versión:</label>
          <input style="width: 100%;" type="text" required="required" class="form-control is-valid" id="version"
            name="version" placeholder="" ng-blur="actualizaPesos(event=$event)" />
        </div>
      </div>

      <!-- Fin Fila 3 -->

      <!-- Fila 4 -->
      <div class="row text-left" style="background-color: #ffffff; padding: 10px 0 10px;">
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <label for="constK">Const.&nbsp;K:</label>
          <input style="width: 100%;" type="text" required="required" class="form-control is-valid" id="constK"
            value="1"
            name="constK" placeholder="" ng-blur="actualizaResultados()"/>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <label for="constC">Const.&nbsp;C:</label>
          <input style="width: 100%;" type="text" required="required" class="form-control is-valid" id="constC"
            value="1"
            name="constC" placeholder="" ng-blur="actualizaResultados()"/>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <label for="sta">Sta:</label>
          <input type="text" required="required" class="form-control is-valid" id="sta" placeholder="" value="1"
            name="sta" size="10" ng-blur="actualizaResultados()"/>

        </div>
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <label for="refsta">Ref.&nbsp;Sta:</label>
          <input type="text" required="required" class="form-control is-valid" id="refsta" placeholder="" 
            value=".8"
            name="refsta" size="10" ng-blur="actualizaResultados()"/>

        </div>
      </div>

      <!-- Fin fila 4 -->

      <!-- Fila 5 -->
      <!-- <div class="row text-left" style="background-color: #eeeeee; padding: 10px 0 10px;">
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <label for="mzfw"><b>MZFW+Comb</b>(MZFW+FOB)&nbsp;<b>A</b>:</label>
          <input type="text" required="required" class="form-control is-valid" id="mzfw" placeholder="" name="mzfw"
            value="" size="10" />
        </div>
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <label for="anpista"><b>An.&nbsp;Pista</b>(Awy.&nbsp;Analysis)&nbsp;<b>B</b>:</label>
          <input type="text" required="required" class="form-control is-valid" id="anpista" placeholder=""
            name="anpista" value="" size="10" />

        </div>
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <label for="LEMAC"><b>MLW+CdC</b>(MLW+TF)&nbsp;<b>A</b>:</label>
          <input type="text" required="required" class="form-control is-valid" id="mlw" placeholder="" name="mlw"
            value="" size="10" />

        </div>
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
          <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
              <label for="temp">Temp.:</label>
              <input type="text" required="required" class="form-control is-valid" id="temp" placeholder="" name="temp"
                value="" size="5" />
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
              <label for="flaps">Flaps:
              </label>
              <input type="text" required="required" class="form-control is-valid" id="flaps" placeholder=""
                name="flaps" value="" size="5" />
            </div>
          </div>
        </div>
      </div> -->
      <!-- Fin Fila 5 -->

      <br />
      <br />
      <!-- tabla Cabina de pasajeros -->
      <h3 class="text-info">Cabina&nbsp;de&nbsp;Pasajeros</h3>

      <div class="row text-center">
        <table style="width: 100%;" class="table-striped">
          <thead class="text-center">
            <tr>
              <th>
                Hombre
              </th>
              <th>
                Mujer
              </th>
              <th>
                Niño
              </th>
              <th>

              </th>
              <th>
                Peso
              </th>
              <th>
                UI
              </th>
            </tr>
          </thead>
          <tbody>
            <tr ng-repeat="cabPas in cabPasArr">
              <td>
                <input type="text" class="form-control is-valid" required="required"
                  name="AdultoMasculino<%cabPas['cabP']['A']%>" id="AdultoMasculino<%cabPas['cabP']['A']%>"
                  placeholder="" value="<%cabPas['cabP']['M']%>" ng-model="cabPas[$index]['cabP']['M']"
                  ng-change="sumaPesoFila($index);sumaPesoCol(0);validaPesoMaximoPasajeros($index, 'AdultoMasculino');" />
              </td>
              <td>
                <input type="text" required="required" name="AdultoFemenino<%cabPas['cabP']['A']%>"
                  id="AdultoFemenino<%cabPas['cabP']['A']%>" placeholder="" class="form-control is-valid"
                  value="<%cabPas['cabP']['F']%>" ng-model="cabPas[$index]['cabP']['F']"
                  ng-change="sumaPesoFila($index);sumaPesoCol(1);validaPesoMaximoPasajeros($index, 'AdultoFemenino')" />
              </td>
              <td>
                <input type="text" required="required" name="Ninio<%cabPas['cabP']['A']%>"
                  id="Ninio<%cabPas['cabP']['A']%>" placeholder="" class="form-control is-valid"
                  value="<%cabPas['cabP']['N']%>" ng-model="cabPas[$index]['cabP']['N']"
                  ng-change="sumaPesoFila($index);sumaPesoCol(2);validaPesoMaximoPasajeros($index, 'Ninio')" />
              </td>
              <td class="text-center">
                <b><%cabPas['cabP']['A']%></b>
              </td>
              <td>
                <input type="text" required="required" name="Peso<%cabPas['cabP']['A']%>"
                  id="Peso<%cabPas['cabP']['A']%>" placeholder="" class="form-control is-valid"
                  value="<%cabPas['cabP']['P']%>" disabled />
              </td>
              <td>
                <input type="text" required="required" name="UnidadIn<%cabPas['cabP']['A']%>"
                  id="UnidadIn<%cabPas['cabP']['A']%>" placeholder="" class="form-control is-valid"
                  value="<%cabPas['cabP']['UI']%>" />
              </td>
            </tr>
            <tr>
              <td>
                <input type="text" id="t1" class="form-control is-valid" name="t1" disabled />
              </td>
              <td>
                <input type="text" id="t2" class="form-control is-valid" name="t2" disabled />
              </td>
              <td>
                <input type="text" id="t3" class="form-control is-valid" name="t3" disabled />
              </td>
              <td>
                <b>T</b>
              </td>
              <td>
                <input type="text" id="total" class="form-control is-valid" name="total" disabled />
              </td>
              <td>
                {!! csrf_field() !!}

                <label class="sr-only" for="inlineFormInputGroup is-valid">L</label>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <div class="input-group-text">L</div>
                  </div>
                  <input type="text" class="form-control is-valid" id="limite" name="limite" placeholder=""
                    value="{{old('limite')}}">
                </div>

              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <br />
      <button type="button" class="btn btn-primary" ng-click="agregaCabPas()">Agregar</button>
      <button type="button" class="btn btn-danger" ng-click="eliminaCabPas()">Eliminar</button>

      <!-- Fin Tabla Cabina de pasajeros -->

      <br />
      <br />
      <br />

      <!-- tabla Compartimiento -->
      <h3 class="text-info">Compartimiento</h3>

      <div class="row text-center">
        <table name="compartimiento" style="width: 100%;" id="compartimiento" class="table-striped text-center">
          <thead>
            <tr>
              <th>
                Peso Máximo
              </th>
              <th></th>
              <th>
                Peso
              </th>
              <th>Unidad&nbsp;&Iacute;ndice</th>
            </tr>
          </thead>
          <tbody>
            <tr ng-repeat="comp in compArr">
              <td>
                <input type="text" required="required" name="Max<%comp['comp']['A']%>" id="Max<%comp['comp']['A']%>"
                  placeholder="" class="form-control is-valid" value="<%comp['comp']['max']%>" />
              </td>
              <td>
                <b><%comp['comp']['A']%></b>
              </td>
              <td>
                <input type="text" required="required" name="PesoCom<%comp['comp']['A']%>"
                  id="PesoCom<%comp['comp']['A']%>" placeholder="" class="form-control is-valid"
                  value="<%comp['comp']['peso']%>" ng-blur="validaPesoMaximo($index);sumaPesoComp()" />
              </td>
              <td>
                <input type="text" required="required" name="UIcom<%comp['comp']['A']%>" id="UIcom<%comp['comp']['A']%>"
                  placeholder="" class="form-control is-valid" value="<%comp['comp']['UI']%>" disabled />
              </td>
            </tr>
            <tr>
              <td></td>
              <td>
                <span class="">
                  <b>TCP:</b>
                </span>
              </td>
              <td>
                <input type="text" required="required" name="TotalPesoCarga" id="TotalPesoCarga" placeholder=""
                  class="form-control is-valid" disabled />
              </td>
              <td>
                <input type="text" required="required" name="UIpaga" id="UIpaga" placeholder=""
                  class="form-control is-valid" disabled />
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <br />
      <button type="button" class="btn btn-primary" ng-click="agregaComp()">Agregar</button>
      <button type="button" class="btn btn-danger" ng-click="eliminaComp()">Eliminar</button>
      <!-- fin tabla Compartimiento -->

      <br />
      <br />
      <br />


      <!-- tabla pesos final -->
      <h3 class="text-info">Pesos</h3>
      <div class="row">
        <table style="width: 100%;table-layout: fixed;word-wrap:break-word;" name="pesosFinal" id="pesosFinal"
          class="table-striped">
          <thead>
            <tr>
              <th></th>
              <th>
                Peso&nbsp;Act
              </th>
              <th>
                UI
              </th>
              <th>
                Peso&nbsp;M&aacute;x
              </th>
            </tr>
          </thead>
          <tbody>
            <!-- <tr>
              <td class="text-right">
                <label for="PesoVacio1" class="">Peso Vacio (EW):</label>
              </td>
              <td>
                <input type="text" required="required" name="PesoVacio1" id="PesoVacio1" placeholder="Peso Actual"
                  class="form-control is-valid" />
              </td>
              <td>
                <input type="text" required="required" name="PesoVacio2" id="PesoVacio2" placeholder="Unidad Indice"
                  class="form-control is-valid" />
              </td>
              <td></td>
            </tr> -->
            <tr>
              <td class="text-right">
                <label for="PesoOperacional1" class="">Peso Operacional (OW):</label>
              </td>
              <td>
                <input type="text" required="required" name="PesoOperacional1" id="PesoOperacional1"
                  placeholder="Peso Actual" class="form-control is-valid" value="<%avionPesos.peso_operacional%>"
                  disabled />
              </td>
              <td>
                <input type="text" required="required" name="PesoOperacional2" id="PesoOperacional2"
                  placeholder="Unidad Indice" class="form-control is-valid" disabled />
              </td>
              <td></td>
            </tr>
            <tr>
              <td class="text-right">
                <label for="CargaPaga1" class="">Carga de Paga (Pay Load):</label>
              </td>
              <td>
                <input type="text" required="required" name="CargaPaga1" id="CargaPaga1" placeholder="Peso Actual"
                  class="form-control is-valid" value="<%avionPesos.carga_paga%>" disabled />
              </td>
              <td>
                <input type="text" required="required" name="CargaPaga2" id="CargaPaga2" placeholder="Unidad Indice"
                  class="form-control is-valid" disabled />
              </td>
              <td></td>
            </tr>
            <tr>
              <td class="text-right">
                <label for="PesoCero1" class="">Peso Cero Combustible (ZFW):</label>
              </td>
              <td>
                <input type="text" required="required" name="PesoCero1" id="PesoCero1" placeholder="Peso Actual"
                  class="form-control is-valid" value="<%avionPesos.peso_cero_combustible%>" disabled />
              </td>
              <td>
                <input type="text" required="required" name="PesoCeroUI" id="PesoCeroUI" placeholder="Unidad Indice"
                  class="form-control is-valid" disabled />
              </td>
              <td>
                <input type="text" required="required" name="PesoCeroMax" id="PesoCeroMax" placeholder="Peso Máximo"
                  class="form-control is-valid" ng-blur="validaPesoMaximoPesos()" />
              </td>
            </tr>
            <!-- <tr>
              <td class="text-right">
                <label for="CombustibleDespegue1" class="">Combustible al Despegue (FOB):</label>
              </td>
              <td>
                <input type="text" required="required" name="CombustibleDespegue1" id="CombustibleDespegue1"
                  placeholder="Peso Actual" class="form-control is-valid" />
              </td>
              <td>
                <input type="text" required="required" name="CombustibleDespegue2" id="CombustibleDespegue2"
                  placeholder="Unidad Indice" class="form-control is-valid" />
              </td>
              <td></td>
            </tr>

            <tr>
              <td class="text-right">
                <label for="PesoRampa1" class="">Peso en Rampa (RW):</label>
              </td>
              <td>
                <input type="text" required="required" name="PesoRampa1" id="PesoRampa1" placeholder="Peso Actual"
                  class="form-control is-valid" />
              </td>
              <td>
                <input type="text" required="required" name="PesoRampa2" id="PesoRampa2" placeholder="Unidad Indice"
                  class="form-control is-valid" />
              </td>
              <td>
                <input type="text" required="required" name="PesoRampaMax" id="PesoRampaMax" placeholder="Peso Máximo"
                  class="form-control is-valid" />
              </td>
            </tr> -->

            <tr>
              <td class="text-right">
                <label for="CombustibleTaxi1" class="">Combustible de Taxi (TW):</label>
              </td>
              <td>
                <input type="text" required="required" name="CombustibleTaxi1" id="CombustibleTaxi1"
                  placeholder="Peso Actual" class="form-control is-valid" value="<%avionPesos.peso_taxi%>" disabled />
              </td>
              <td>
                <input type="text" required="required" name="CombustibleTaxi2" id="CombustibleTaxi2"
                  placeholder="Unidad Indice" class="form-control is-valid" disabled />
              </td>
              <td>

              </td>
            </tr>


            <tr>
              <td class="text-right">
                <label for="PesoDespegue1" class="">Peso Despegue (TOW):</label>
              </td>
              <td>
                <input type="text" required="required" name="PesoDespegue1" id="PesoDespegue1" placeholder="Peso Actual"
                  class="form-control is-valid" value="<%avionPesos.peso_despegue_tow%>" disabled />
              </td>
              <td>
                <input type="text" required="required" name="PesoDespegue2" id="PesoDespegue2"
                  placeholder="Unidad Indice" class="form-control is-valid" disabled />
              </td>
              <td>
                <input type="text" required="required" name="PesoDespegueMax" id="PesoDespegueMax"
                  placeholder="Peso Máximo" class="form-control is-valid" ng-blur="validaPesoMaximoPesos()" />
              </td>
            </tr>


            <!-- <tr>
              <td class="text-right">
                <label for="ConsumoCombustible1" class="">Consumo de Combustible (TF):</label>
              </td>
              <td>
                <input type="text" required="required" name="ConsumoCombustible1" id="ConsumoCombustible1"
                  placeholder="Peso Actual" class="form-control is-valid" />
              </td>
              <td>
                <input type="text" required="required" name="ConsumoCombustible2" id="ConsumoCombustible2"
                  placeholder="Unidad Indice" class="form-control is-valid" />
              </td>
              <td>

              </td>
            </tr>  -->


            <tr>
              <td class="text-right">
                <label for="PesoAterrizaje1" class="">Peso Aterrizaje (LW):</label>
              </td>
              <td>
                <input type="text" required="required" name="PesoAterrizaje1" id="PesoAterrizaje1"
                  placeholder="Peso Actual" class="form-control is-valid" value="<%avionPesos.peso_aterrizaje%>"
                  disabled />
              </td>
              <td>
                <input type="text" required="required" name="PesoAterrizaje2" id="PesoAterrizaje2"
                  placeholder="Unidad Indice" class="form-control is-valid" disabled />
              </td>
              <td>
                <input type="text" required="required" name="PesoAterrizajeMax" id="PesoAterrizajeMax"
                  placeholder="Peso Máximo" class="form-control is-valid" ng-blur="validaPesoMaximoPesos()" />
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- fin tabla pesos final -->
      <br />
      <!-- <p><button class="btn btn-primary btn-block" type="submit" name="Guardar" id="Guardar">Guardar</button></p> -->
    </span>

  </form>

  <!-- <div class="form-row" class="text-center">
    <div class="col-md-4 mb-3 off offset-md-4">
      <h2>
        Estabilizador
        <input type="text" required="required" class="form-control is-valid" id="validationServer" placeholder=""
          value="" size="10" class="form-control is-valid" />
      </h2>
      <p>&nbsp;</p>
      <p >
        <img src="{{ asset('images/diagrama_balance.png') }}" alt="diagrama_balance"/>
      </p>
      <p>&nbsp;</p>
    </div>
  </div> -->

</div>

@endsection